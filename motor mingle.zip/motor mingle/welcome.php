<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Motor Mingle!</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color:aliceblue;
            overflow: hidden; /* Prevents horizontal scrollbar due to animation */
            position: relative; /* Ensures proper positioning of the car */
        }
        .container {
            width: 80%;
            margin: auto;
            text-align: center;
            padding-top: 50px;
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
            font-size: 18px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            position: relative; 
            z-index: 1; 
        }
        .btn:hover {
            background-color: #0056b3;
            transform: scale(1.05); /
        }
        
        @keyframes driveCar {
            0% { transform: translateX(-200px); 
            100% { transform: translateX(110%); }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Motor Mingle!</h1>
        <p>Your Ultimate Destination for Car and Bike Enthusiasts</p>
        <p>Explore our vast collection, connect with like-minded enthusiasts, and experience the thrill of the road.</p>
        <a href="menu page.html" class="btn">Get Started</a> 
</body>
</html>
    </div>
</body>
</html>
