<?php
// Initialize the session
session_start();

// Check if last activity time is set in session
if (isset($_SESSION['last_activity'])) {
    // Calculate the time difference between current time and last activity time
    $inactive_time = time() - $_SESSION['last_activity'];

    // If inactive time exceeds 30 seconds
    if ($inactive_time >= 30) {
        // Unset all of the session variables
        $_SESSION = array();

        // Destroy the session
        session_destroy();

        // Redirect to login page after logout
        header("location: login.php");
        exit;
    }
}

// Update last activity time in session
$_SESSION['last_activity'] = time();
?>
