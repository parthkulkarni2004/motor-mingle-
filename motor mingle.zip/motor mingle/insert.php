<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "booking";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL query
$sql = "INSERT INTO `order` (username, modelname, gender, email, phno) VALUES (?, ?, ?, ?, ?)";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare and bind the SQL statement
    $stmt = $conn->prepare($sql);
    
    // Check if the statement preparation is successful
    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("sssss", $username, $modelname, $gender, $email, $phno);

        // Set parameters
        $username = isset($_POST['username']) ? $_POST['username'] : '';
        $modelname = isset($_POST['modelname']) ? $_POST['modelname'] : '';
        $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
        $email = isset($_POST['email']) ? $_POST['email'] : '';
        $phno = isset($_POST['phno']) ? $_POST['phno'] : '';

        // Execute the statement
        if ($stmt->execute()) {
            echo "Your booking has been placed successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Error preparing SQL statement: " . $conn->error;
    }
} else {
    echo "Form not submitted";
}

// Close connection
$conn->close();
?>
