-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2024 at 06:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `username` text NOT NULL,
  `modelname` text NOT NULL,
  `gender` char(1) NOT NULL,
  `email` text NOT NULL,
  `phno` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`username`, `modelname`, `gender`, `email`, `phno`) VALUES
('swapnil', 'swift', 'm', 'swapnil123@gmail.com', '9044533423'),
('swapnil', 'swift', 'm', 'swapnil123@gmail.com', '9044533423'),
('swapnil', 'swift', 'm', 'swapnil123@gmail.com', '9044533423'),
('swapnil', 'swift', 'm', 'swapnil123@gmail.com', '9044533423'),
('swapnil', 'swift', 'm', 'swapnil123@gmail.com', '09044533423'),
('swapnil', 'swift', 'm', 'swapnil123@gmail.com', '09044533423'),
('swapnil', 'swift', 'm', 'swapnil123@gmail.com', '09044533423');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
